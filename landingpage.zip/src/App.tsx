import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence, useScroll, useSpring } from 'motion/react';
import { 
  CheckCircle2, 
  Star, 
  Gift, 
  ShieldCheck, 
  ChevronDown, 
  Zap, 
  Heart, 
  Smile, 
  Sparkles,
  ArrowRight,
  HelpCircle,
  X,
  Play,
  Check,
  MousePointer2,
  Trophy
} from 'lucide-react';

const COLORS = {
  pink: '#F116CB',
  purple: '#AD06FD',
  yellow: '#FFBF00',
  white: '#FFFFFF',
};

// --- Atomic Components ---

const Badge = ({ children, className = "" }: { children: React.ReactNode, className?: string }) => (
  <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold tracking-wide uppercase ${className}`}>
    {children}
  </span>
);

const SectionHeading = ({ title, subtitle, centered = true }: { title: string, subtitle?: string, centered?: boolean }) => (
  <div className={`mb-16 ${centered ? 'text-center' : ''}`}>
    {subtitle && (
      <motion.p 
        initial={{ opacity: 0, y: 10 }}
        whileInView={{ opacity: 1, y: 0 }}
        className="text-brand-pink font-bold uppercase tracking-widest text-sm mb-4"
      >
        {subtitle}
      </motion.p>
    )}
    <motion.h2 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      className="text-3xl md:text-4xl font-black italic tracking-tight"
      style={{ color: COLORS.purple }}
    >
      {title}
    </motion.h2>
  </div>
);

const Decoration = ({ className = "", delay = 0, size = 10 }: { className?: string, delay?: number, size?: number }) => (
  <motion.div
    animate={{ 
      rotate: [0, 10, -10, 0],
      scale: [1, 1.1, 1],
    }}
    transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay }}
    className={`absolute pointer-events-none ${className}`}
  >
    <div className={`w-${size} h-${size} rounded-xl bg-white shadow-lg flex items-center justify-center -rotate-12 border-2 border-yellow-200`}>
      <Sparkles className="text-brand-yellow" size={size * 1.5} />
    </div>
  </motion.div>
);

// --- Main App ---

export default function App() {
  const [showUpsell, setShowUpsell] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30, restDelta: 0.001 });

  const scrollToPlans = () => {
    document.getElementById('planos')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleBasicSelect = () => setShowUpsell(true);
  
  const handleCheckout = (planName: string) => {
    alert(`Redirecionando para o seguro checkout do plano ${planName}!`);
    setShowUpsell(false);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Scroll Progress */}
      <motion.div className="fixed top-0 left-0 right-0 h-1 bg-brand-pink z-[100] origin-left" style={{ scaleX }} />

      {/* 1. Urgency Banner (Fixed) */}
      <div className="fixed top-0 left-0 right-0 bg-brand-pink text-white py-2 px-4 font-bold text-[9px] sm:text-[10px] uppercase tracking-[0.2em] z-[70] text-center overflow-hidden shadow-md">
        <motion.div 
          animate={{ x: [0, -5, 0] }} 
          transition={{ duration: 2, repeat: Infinity }}
          className="flex items-center justify-center gap-3"
        >
          <Zap size={12} fill="currentColor" />
          <span>Oferta exclusiva termina em 14:59 minutos</span>
          <Zap size={12} fill="currentColor" />
        </motion.div>
      </div>

      {/* Floating Header */}
      <nav className="fixed top-12 left-1/2 -translate-x-1/2 w-[90%] max-w-4xl z-50">
        <div className="glass rounded-2xl px-5 py-2.5 flex justify-between items-center shadow-xl border-2 border-white/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-brand-purple flex items-center justify-center shadow-md transform -rotate-6">
              <Smile className="text-white" size={18} />
            </div>
            <span className="font-black text-lg tracking-tight text-brand-purple">KIDS<span className="text-brand-pink italic">MÉTODO</span></span>
          </div>
          <div className="hidden md:flex items-center gap-6 font-bold text-slate-600 text-[13px]">
            <a href="#oq-receber" className="hover:text-brand-purple transition-colors">Conteúdo</a>
            <a href="#planos" className="hover:text-brand-purple transition-colors">Planos</a>
            <a href="#faq" className="hover:text-brand-purple transition-colors">Dúvidas</a>
          </div>
          <button 
            onClick={scrollToPlans}
            className="bg-brand-yellow hover:bg-brand-yellow/90 text-slate-900 font-bold px-5 py-2 rounded-xl shadow-md active:scale-95 transition-all text-xs flex items-center gap-1.5 group"
          >
            INICIAR <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </nav>

      {/* 2. Hero Section */}
      <section className="relative pt-36 pb-20 px-6 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full -z-10">
          <div className="absolute top-20 left-[10%] w-64 h-64 bg-brand-pink/5 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-[10%] w-80 h-80 bg-brand-purple/10 rounded-full blur-3xl opacity-50" />
        </div>

        <div className="max-w-5xl mx-auto flex flex-col items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center relative z-10"
          >
            <Badge className="bg-brand-pink/10 text-brand-pink mb-4">
              <Sparkles size={12} className="animate-pulse" /> 100% Pedagógico
            </Badge>
            <h1 className="text-4xl md:text-6xl font-black text-brand-purple leading-[1.1] tracking-tighter mb-6 max-w-3xl italic">
              Conecte seu filho à sua <span className="text-brand-pink underline decoration-brand-yellow decoration-4 underline-offset-4">Melhor Versão</span>
            </h1>
            <p className="text-base md:text-lg text-slate-500 max-w-xl mx-auto mb-10 font-medium leading-relaxed">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={scrollToPlans}
                className="bg-brand-purple text-white px-8 py-5 rounded-2xl font-black text-lg shadow-brand hover:translate-y-[-2px] active:translate-y-[4px] active:shadow-none transition-all flex items-center gap-2"
              >
                GARANTIR MINHA VAGA <Play size={18} fill="currentColor" />
              </motion.button>
              <div className="flex items-center gap-1.5 text-slate-400 font-bold text-sm">
                <ShieldCheck size={16} /> Acesso de 1 ano
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 2.5 VSL Section */}
      <section className="py-12 px-6 bg-white overflow-hidden">
        <div className="max-w-4xl mx-auto flex flex-col items-center">
          <div className="relative group cursor-pointer">
            {/* Phone Frame Mockup */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative w-64 sm:w-72 aspect-[9/16] bg-slate-900 rounded-[3rem] shadow-[0_0_50px_-12px_rgba(241,22,203,0.3)] border-8 border-slate-900 overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-brand-purple/20 to-brand-pink/20 mix-blend-overlay" />
              
              {/* Inner Content Placeholder */}
              <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center">
                <motion.div 
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="w-16 h-16 rounded-full bg-brand-pink flex items-center justify-center text-white shadow-lg mb-4"
                >
                  <Play size={32} fill="currentColor" className="ml-1" />
                </motion.div>
                <div className="text-white/60 text-xs font-bold uppercase tracking-widest animate-pulse">
                  Clique para assistir
                </div>
              </div>

              {/* Progress Bar Mockup */}
              <div className="absolute bottom-6 left-6 right-6 h-1 bg-white/20 rounded-full overflow-hidden">
                <motion.div 
                  animate={{ scaleX: [0, 0.4, 0.7, 1] }}
                  transition={{ duration: 10, repeat: Infinity }}
                  className="h-full bg-brand-pink origin-left"
                />
              </div>
            </motion.div>

            {/* Decorations */}
            <Decoration className="-top-6 -left-6" delay={0.1} size={8} />
            <Decoration className="top-1/2 -right-8" delay={0.4} size={6} />
            <div className="absolute -bottom-4 -right-2 bg-brand-yellow text-slate-900 px-3 py-1 rounded-lg font-black text-[10px] shadow-lg transform rotate-6 animate-bounce">
              PLAY AGORA!
            </div>
          </div>

          <motion.div 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="mt-8 text-center max-w-sm px-4"
          >
            <p className="text-slate-400 font-medium italic text-sm leading-relaxed">
              "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo."
            </p>
          </motion.div>
        </div>
      </section>

      {/* 3. O que a pessoa vai receber (Dynamic Grid) */}
      <section id="oq-receber" className="py-20 px-6 bg-slate-50 relative overflow-hidden">
        <div className="max-w-5xl mx-auto">
          <SectionHeading 
            title="O que preparamos para vocês" 
            subtitle="Explore o conteúdo"
          />
          
          <div className="flex flex-wrap justify-center gap-6">
            {[1, 2, 3].map((i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`${i === 1 ? 'md:w-[calc(58%-12px)]' : i === 2 ? 'md:w-[calc(42%-12px)]' : 'md:w-[60%]'} w-full bg-white p-8 rounded-[32px] shadow-lg border border-slate-100 group hover:border-brand-purple transition-all`}
              >
                <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center mb-6 group-hover:bg-brand-purple group-hover:text-white transition-colors">
                  <Star size={20} />
                </div>
                <h3 className="text-2xl font-black text-brand-purple mb-3">Experiência {i}</h3>
                <p className="text-slate-500 text-sm font-medium leading-relaxed">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris urna purus, congue non feugiat sit amet, maximus vel felis.
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Para quem é (Feature List) */}
      <section className="py-24 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="relative p-6">
              <div className="blob w-full aspect-square bg-gradient-to-br from-brand-yellow/20 to-brand-pink/10 absolute -z-10 scale-110" />
              <div className="bg-white p-3 rounded-[48px] shadow-2xl border-4 border-brand-yellow rotate-2">
                <div className="bg-slate-50 aspect-square rounded-[36px] flex items-center justify-center">
                   <Smile size={100} className="text-brand-yellow" />
                </div>
              </div>
              <Decoration className="top-4 left-4" delay={0.2} size={8} />
              <Decoration className="bottom-14 right-4" delay={0.5} size={10} />
            </div>

            <div>
              <SectionHeading 
                title="Isso é para você que..." 
                subtitle="Compatibilidade"
                centered={false}
              />
              <div className="space-y-4">
                {[
                  "Busca um tempo de qualidade real em família",
                  "Quer afastar seu filho do excesso de telas",
                  "Deseja estimular a criatividade e cognição",
                  "Acredita que aprender deve ser divertido"
                ].map((item, idx) => (
                  <motion.div 
                    key={idx}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className="flex gap-3.5 items-start"
                  >
                    <div className="mt-1 w-7 h-7 rounded-full bg-brand-purple text-white flex shrink-0 items-center justify-center shadow-md">
                      <Check size={14} />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-brand-purple leading-tight mb-1">{item}</h4>
                      <p className="text-slate-400 text-xs">Desenvolvido por especialistas em educação lúdica.</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Objeções (Clean Accordeon/Grid) */}
      <section className="py-20 px-6 bg-brand-purple/5">
        <div className="max-w-3xl mx-auto">
          <SectionHeading title="Suas dúvidas, resolvidas" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-2xl shadow-md">
              <h4 className="text-lg font-black mb-2 text-brand-purple leading-tight">"Eu não tenho tempo"</h4>
              <p className="text-slate-500 text-sm italic leading-relaxed">"Resolvemos isso com sessões de apenas 15 minutos que geram resultados imediatos."</p>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-md">
              <h4 className="text-lg font-black mb-2 text-brand-purple leading-tight">"É muito caro"</h4>
              <p className="text-slate-500 text-sm italic leading-relaxed">"Menos que o valor de um lanche por mês para um futuro de aprendizado."</p>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Bônus (Cards) */}
      <section className="py-20 px-6 bg-white overflow-hidden">
        <div className="max-w-5xl mx-auto">
          <SectionHeading title="Bônus Irresistíveis" subtitle="Presentes exclusivos" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { title: "Guia de Sono", icon: Heart },
              { title: "Diário de Emoções", icon: Smile },
              { title: "Cantinho Kids", icon: Trophy }
            ].map((bonus, i) => (
              <motion.div 
                key={i}
                whileHover={{ scale: 1.03, rotate: i % 2 === 0 ? 1 : -1 }}
                className="bg-white p-8 rounded-[32px] shadow-xl border-3 border-dashed border-slate-100 relative"
              >
                <div className="absolute -top-3 -right-3 bg-brand-yellow text-slate-800 px-3 py-0.5 rounded-full font-black text-[10px] shadow-md uppercase">
                  GRÁTIS
                </div>
                <div className="w-12 h-12 rounded-xl bg-brand-pink/5 flex items-center justify-center mb-5 text-brand-pink">
                  <bonus.icon size={28} />
                </div>
                <h3 className="text-xl font-black text-brand-purple mb-3">{bonus.title}</h3>
                <p className="text-slate-500 text-sm font-medium">Conteúdo premium que complementa sua jornada.</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. Planos (High Conversion) */}
      <section id="planos" className="py-24 px-6 bg-slate-50 relative overflow-hidden">
        <div className="absolute top-1/2 left-0 w-full h-[400px] bg-brand-purple -rotate-2 -z-10 translate-y-[-50%]" />
        
        <div className="max-w-5xl mx-auto">
          <SectionHeading title="Acesso Imediato" subtitle="Investimento" />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
            {/* Plano Básico */}
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              className="bg-white p-10 rounded-[40px] shadow-xl border border-slate-100 flex flex-col items-center text-center relative"
            >
              <h3 className="text-lg font-black text-slate-400 mb-6 uppercase tracking-widest">Plano Kids</h3>
              <div className="mb-6">
                <span className="text-sm font-bold text-slate-300 block mb-1">Pagamento Único</span>
                <div className="flex items-center justify-center text-slate-700">
                   <span className="text-xl font-bold self-start mt-2">R$</span>
                   <span className="text-7xl font-black italic">10</span>
                   <div className="flex flex-col text-left ml-1.5">
                     <span className="text-2xl font-bold">,00</span>
                   </div>
                </div>
              </div>
              <ul className="text-left space-y-3.5 mb-10 w-full max-w-xs mx-auto font-bold text-slate-600 text-sm">
                <li className="flex items-center gap-3"><CheckCircle2 className="text-brand-pink" size={16} /> Conteúdo Base Completo</li>
                <li className="flex items-center gap-3"><CheckCircle2 className="text-brand-pink" size={16} /> Suporte via E-mail</li>
                <li className="flex items-center gap-3"><CheckCircle2 className="text-brand-pink" size={16} /> Certificado Digital</li>
              </ul>
              <button 
                onClick={handleBasicSelect}
                className="w-full py-4 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-black text-lg transition-all"
              >
                ESCOLHER BÁSICO
              </button>
            </motion.div>

            {/* Plano Premium */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.98 }}
              whileInView={{ opacity: 1, scale: 1 }}
              className="bg-white p-10 rounded-[48px] shadow-[0_30px_70px_-15px_rgba(173,6,253,0.2)] border-4 border-brand-yellow flex flex-col items-center text-center relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 right-0 py-1.5 bg-brand-yellow text-brand-purple font-black text-[9px] uppercase tracking-[0.25em]">
                O Plano Favorito dos Pais
              </div>
              
              <h3 className="text-xl font-black text-brand-purple mb-6 uppercase mt-6 tracking-widest">Premium Plus</h3>
              <div className="mb-6">
                <span className="text-sm font-bold text-brand-pink block line-through opacity-40 mb-1">De R$ 97,00 por</span>
                <div className="flex items-center justify-center text-brand-purple">
                   <span className="text-xl font-bold self-start mt-2">R$</span>
                   <span className="text-8xl font-black italic">27</span>
                   <div className="flex flex-col text-left ml-2">
                     <span className="text-2xl font-bold">,00</span>
                     <span className="text-[10px] font-black uppercase text-brand-pink animate-pulse">HOJE!</span>
                   </div>
                </div>
              </div>
              <ul className="text-left space-y-3.5 mb-10 w-full max-w-xs mx-auto font-bold text-slate-700 text-sm">
                <li className="flex items-center gap-3 text-brand-pink font-black"><Sparkles size={16} /> Tudo do Plano Kids</li>
                <li className="flex items-center gap-3"><CheckCircle2 className="text-brand-purple" size={16} /> Bônus Vips Inclusos</li>
                <li className="flex items-center gap-3"><CheckCircle2 className="text-brand-purple" size={16} /> Suporte Especial WhatsApp</li>
                <li className="flex items-center gap-3"><CheckCircle2 className="text-brand-purple" size={16} /> Atividades Extras Mensais</li>
              </ul>
              <button 
                onClick={() => handleCheckout("Premium")}
                className="w-full py-5 rounded-2xl bg-brand-purple text-white font-black text-xl shadow-brand hover:translate-y-[-3px] active:translate-y-[2px] transition-all flex items-center justify-center gap-2.5"
              >
                QUERO O PREMIUM <MousePointer2 size={20} />
              </button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 8. Garantia (Professional seal) */}
      <section className="py-24 px-6 bg-white overflow-hidden">
        <div className="max-w-4xl mx-auto rounded-[48px] bg-white p-10 md:p-14 text-center relative border-4 border-slate-50 shadow-[0_32px_64px_-12px_rgba(173,6,253,0.1)]">
          <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-24 h-24 bg-brand-yellow rounded-full flex items-center justify-center shadow-xl border-8 border-white group">
            <Trophy className="text-white group-hover:scale-110 transition-transform" size={40} />
          </div>
          
          <div className="mt-8">
            <SectionHeading title="Sua Satisfação é Prioridade" centered subtitle="Garantia Incondicional" />
          </div>

          <div className="flex flex-col md:flex-row items-center justify-center gap-10 max-w-2xl mx-auto">
            <div className="relative shrink-0">
              <div className="w-32 h-32 rounded-full bg-brand-pink/5 flex flex-col items-center justify-center border-4 border-brand-pink relative z-10">
                <span className="text-3xl font-black text-brand-pink leading-none">7</span>
                <span className="text-xs font-black text-brand-pink uppercase tracking-tighter">Dias</span>
              </div>
              <div className="absolute -inset-2 bg-brand-pink/10 rounded-full blur-xl animate-pulse" />
            </div>

            <p className="text-lg md:text-xl text-slate-500 font-medium leading-relaxed text-center md:text-left">
              Se em até 7 dias você ou seu filho não amarem a experiência, <span className="text-brand-purple font-bold underline decoration-brand-yellow decoration-4 underline-offset-4">devolvemos 100% do seu dinheiro.</span> Sem perguntas, sem burocracia.
            </p>
          </div>

          {/* Decorative accents */}
          <div className="absolute bottom-4 right-8 opacity-20">
             <ShieldCheck size={80} className="text-brand-purple" />
          </div>
        </div>
      </section>

      {/* 9. FAQ (Polished) */}
      <section id="faq" className="py-20 px-6 bg-slate-50">
        <div className="max-w-2xl mx-auto">
          <SectionHeading title="Perguntas Frequentes" subtitle="Dúvidas comuns" />
          <div className="space-y-3">
            {[
              { q: "O acesso é imediato?", a: "Sim! Logo após a confirmação do pagamento, você recebe um link exclusivo no seu e-mail para baixar e começar." },
              { q: "Quais as formas de pagamento?", a: "Aceitamos Cartão de Crédito, Pix e Boleto Bancário. O Pix libera o acesso na hora!" },
              { q: "Serve para qual idade?", a: "O material é focado no desenvolvimento de crianças entre 3 e 12 anos de idade." },
              { q: "Posso acessar de qualquer lugar?", a: "Com certeza. No celular, tablet ou computador, a diversão acontece onde você estiver." }
            ].map((item, i) => (
              <div 
                key={i} 
                className="bg-white rounded-2xl overflow-hidden border border-slate-200 shadow-sm transition-all hover:border-brand-purple/20"
              >
                <button 
                  onClick={() => setActiveFaq(activeFaq === i ? null : i)}
                  className="w-full p-5 text-left flex justify-between items-center bg-white transition-colors"
                >
                  <span className="font-bold text-base text-brand-purple">{item.q}</span>
                  <div className={`p-1.5 rounded-full bg-slate-50 transition-transform ${activeFaq === i ? 'rotate-180 bg-brand-purple/10 text-brand-purple' : ''}`}>
                    <ChevronDown size={14} />
                  </div>
                </button>
                <AnimatePresence>
                  {activeFaq === i && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="px-5 pb-5 text-slate-500 font-medium text-sm leading-relaxed"
                    >
                      {item.a}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 10. Final Call to Action */}
      <section className="py-24 px-6 text-center">
         <h3 className="text-3xl md:text-5xl font-black text-brand-purple italic mb-8">
           Preparado para <span className="text-brand-pink">começar?</span>
         </h3>
         <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={scrollToPlans}
            className="bg-brand-yellow text-slate-900 px-8 py-5 rounded-2xl font-black text-2xl shadow-lg hover:shadow-xl transition-all"
         >
            ESCOLHER MEU PLANO
         </motion.button>
      </section>

      {/* Footer */}
      <footer className="py-16 bg-brand-purple text-white relative overflow-hidden">
        <div className="max-w-5xl mx-auto px-6 relative flex flex-col items-center">
          <div className="flex items-center gap-2.5 mb-6">
            <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center shadow-lg">
              <Smile className="text-brand-purple" size={20} />
            </div>
            <span className="font-black text-xl tracking-tight uppercase">Kids Método</span>
          </div>
          <div className="flex gap-6 mb-8 text-white/70 font-bold uppercase text-[10px] tracking-widest">
            <button key="privacidade" className="hover:text-white transition-colors cursor-pointer">Privacidade</button>
            <button key="termos" className="hover:text-white transition-colors cursor-pointer">Termos</button>
            <button key="suporte" className="hover:text-white transition-colors cursor-pointer">Suporte</button>
          </div>
          <p className="text-white/50 text-[11px] font-medium tracking-wide italic">
            © {new Date().getFullYear()} Kids Método. Todos os direitos reservados.
          </p>
        </div>
        {/* Decorative background element */}
        <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-3xl" />
      </footer>

      {/* Upsell Modal */}
      <AnimatePresence>
        {showUpsell && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-transparent backdrop-blur-2xl"
              onClick={() => setShowUpsell(false)}
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white w-full max-w-lg rounded-[40px] shadow-2xl relative z-10 overflow-hidden border-4 border-brand-yellow"
            >
              <div className="bg-brand-yellow p-5 text-center">
                 <Badge className="bg-white text-brand-purple mb-1">🎁 Oferta Relâmpago</Badge>
                 <h3 className="text-2xl font-black text-brand-purple uppercase italic tracking-tighter leading-none">ESPERE! NÃO VÁ AINDA!</h3>
              </div>
              
              <div className="p-8 text-center">
                <div className="mb-6">
                  <p className="text-slate-500 font-bold mb-3 text-sm">Vimos que você escolheu o básico, mas...</p>
                  <div className="flex flex-col items-center gap-1.5">
                    <span className="text-slate-300 line-through text-lg font-black italic">DE R$ 27,00</span>
                    <div className="bg-emerald-50 text-emerald-600 px-5 py-3 rounded-2xl border-2 border-emerald-100 w-full max-w-xs">
                      <span className="text-[10px] font-black uppercase block mb-1">PREMIUM POR APENAS</span>
                      <span className="text-5xl font-black italic leading-none">R$ 17,90</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <button 
                    onClick={() => handleCheckout("Premium Upsell")}
                    className="w-full py-5 rounded-2xl bg-brand-pink text-white font-black text-xl shadow-lg hover:translate-y-[-2px] active:translate-y-[2px] transition-all"
                    style={{ boxShadow: `0 6px 0 0 #be185d` }}
                  >
                    QUERO O PREMIUM AGORA
                  </button>
                  <button 
                    onClick={() => handleCheckout("Basic")}
                    className="text-slate-400 font-bold text-xs underline hover:text-slate-600 transition-colors"
                  >
                    Quero manter o básico por R$ 10,00
                  </button>
                </div>
              </div>
              
              <div className="bg-slate-50 p-4 flex items-center justify-center gap-2 text-slate-400 font-bold text-[10px]">
                <ShieldCheck size={14} /> COMPRA 100% SEGURA
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
